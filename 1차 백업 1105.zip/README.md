# selenium-pytest
automator test (Selenium, Pytest, jenkins, etc)
