# Selenium 서버 URL
SELENIUM_URLS = {
    'pc1': 'http://192.168.0.72:4444/wd/hub',
    'pc2': 'http://192.168.0.18:4444/wd/hub',
    'pc3': 'http://192.168.0.106:4444/wd/hub'
}

# 웹사이트 URL
WEBSITE_URL = "https://tb-edu.ontactedu.co.kr/office/goe"
